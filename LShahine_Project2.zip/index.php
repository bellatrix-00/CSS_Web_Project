<?php
$conn = new mysqli("localhost","root","","project2_web");
if ($conn->connect_error) {
    die("Connection Failed " . $conn->connect_error);
}
if (isset($_POST["addtask"])) {
    $task = $_POST["task"];
    $conn -> query("INSERT INTO tasks (task) VALUES ('$task')");
    header("Location: index.php");
}
if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $conn->query("DELETE FROM tasks WHERE id = '$id'");
    header("Location: index.php");
}
if (isset($_GET["complete"])) {
    $id = $_GET["complete"];
    $conn->query("UPDATE tasks SET status ='completed' WHERE id = '$id'");
    header("Location: index.php");
}
$result = $conn->query("SELECT * FROM tasks ORDER BY id DESC");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>homepage</title>
    <link href="https://fonts.googleapis.com/css2?family=Indie+Flower&display=swap" rel="stylesheet"><!---this library will be used to use indie-flowe font-->
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

    <body>
        <nav>
            <ul>
                <li><a href="/Project2/index.php">Home</a></li>
                <li> <a href="/Project2/tasks.php">Tasks</a></li>
                <li> <a href="/Project2/progress.html">Progress</a></li>
                <li> <a href="/Project2/motivation.html">Motivation</a></li>
                 <li><a href="/Project2/feedback.html">Feedback</a></li>
            </ul>
        </nav>
    </body>
    
    

    <div id ="todo-section">
        <h1>To-Do List</h1>
        <form action="index.php" method="post">
            <input type="text" name="task" placeholder="Enter new task:" id="">
            <button type="submit" name="addtask">Add Task</button>
        </form>
       <ul>
       <?php while($row = $result->fetch_assoc()): ?>
            <li class="<?php echo $row["status"]; ?>">
                <strong><?php echo $row["task"]; ?></strong>
                <div class="actions">
                    <a href="index.php?complete=<?php echo $row['id']; ?>">Complete</a>
                    <a href="index.php?delete=<?php echo $row['id']; ?>">Delete</a>
                </div>
            </li>
        <?php endwhile ?>
       </ul>
    </div>

        </body>
   
</section>


    <div class="about-panel">
        <h2 id="toggleabout" style="cursor:pointer">About Us</h2>
        <div id="aboutcontent" style="display:none; padding:50px; background-color:#e0cef0;">
        <p>
  This platform helps you gamify your productivity, stay focused, and collaborate with friends in real-time using 
  <span class="tooltip">
    <a href="https://discord.gg/DedK7jPsbn" >Discord</a>
    <span class="tooltiptext">Join Study Room</span>
  </span>. You can also add tasks in the tasks page by using the calander, track your progress in progress tracker page. Check out our motivation page to keep you going! Also your feedback will help us improve so make sure to submit the form.  
</p>

  
    </div>
    <style>
.tooltip {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;

  /* Position the tooltip */
  position: absolute;
  z-index: 1;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
}
</style>
</div>

  
    <footer>
        <p>2025 Gamified To-Do List | Stay Organized, Stay Motivated! <i class="fa fa-heart" style="font-size:30px;color:purple;"></i></p>
    </footer>

    <script>
    // Wait for DOM to be fully loaded
    $(document).ready(function() {
        // Toggle about panel
        $("#toggleabout").click(function() {
            $("#aboutcontent").slideToggle("slow");
        });

    });
</script> 
</style></body>
</html>