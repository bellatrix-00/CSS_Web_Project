<?php
// database_connection.php
$host = "localhost"; // or your host
$username = "root"; // your database username
$password = ""; // your database password
$database = "project2_web"; // your database name

// Create connection
$con = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Set charset to utf8
mysqli_set_charset($con, "utf8");
?>