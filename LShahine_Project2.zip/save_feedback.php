<?php
require 'connect.php';

header('Content-Type: application/json');

// Get POST data
$name = isset($_POST['name']) ? mysqli_real_escape_string($con, trim($_POST['name'])) : 'Anonymous';
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$comments = isset($_POST['comments']) ? mysqli_real_escape_string($con, trim($_POST['comments'])) : '';
$bugs = isset($_POST['bugs']) ? mysqli_real_escape_string($con, trim($_POST['bugs'])) : '';

// Validate data
if ($rating < 1 || $rating > 5 || empty($comments)) {
    echo json_encode(['status' => false, 'msg' => 'Invalid input data']);
    exit;
}

// Insert into database
$query = "INSERT INTO feedback (name, rating, comments, bugs, created_at) 
          VALUES ('$name', $rating, '$comments', '$bugs', NOW())";

if(mysqli_query($con, $query)) {
    echo json_encode(['status' => true, 'msg' => 'Thank you for your feedback!']);
} else {
    echo json_encode(['status' => false, 'msg' => 'Sorry, there was an error submitting your feedback.']);
}

mysqli_close($con);
?>