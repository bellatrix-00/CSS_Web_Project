<!DOCTYPE html>
<html>
<head>
<title>Calendar</title>

<link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />
<!-- JS for jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- JS for full calender -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
<!-- bootstrap css and js -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Add this style block to protect calendar dimensions -->

</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-lg-12">
            <nav>
                <ul>
                    <li><a href="/Project2/index.php">Home</a></li>
                    <li><a href="/Project2/tasks.php">Tasks</a></li>
                    <li><a href="/Project2/progress.html">Progress</a></li>
                    <li><a href="/Project2/motivation.html">Motivation</a></li>
                    <li><a href="/Project2/feedback.html">Feedback</a></li>
                </ul>
            </nav>
            
            <div class="fullcalendar-container">  <!-- Added wrapper div -->
                <div id="calendar"></div>
            </div>
		</div>
	</div>
</div>
<!-- Start popup dialog box -->
<div class="modal fade" id="event_entry_modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
	<div class="modal-dialog modal-md" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modalLabel">Add New Event</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">в</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="img-container">
					<div class="row">
						<div class="col-sm-12">  
							<div class="form-group">
							  <label for="event_name">Event name</label>
							  <input type="text" name="event_name" id="event_name" class="form-control" placeholder="Enter your event name">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">  
							<div class="form-group">
							  <label for="event_start_date">Event start</label>
							  <input type="date" name="event_start_date" id="event_start_date" class="form-control onlydatepicker" placeholder="Event start date">
							 </div>
						</div>
						<div class="col-sm-6">  
							<div class="form-group">
							  <label for="event_end_date">Event end</label>
							  <input type="date" name="event_end_date" id="event_end_date" class="form-control" placeholder="Event end date">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" onclick="save_event()">Save Event</button>
            </div>
		</div>
	</div>
</div>
<!-- End popup dialog box -->

<br>

<script>
$(document).ready(function() {
	display_events();
}); //end document.ready block

function display_events() {
	var events = new Array();
$.ajax({
    url: 'display_event.php',  
    dataType: 'json',
    success: function (response) {
         
    var result=response.data;
    $.each(result, function (i, item) {
    	events.push({
            event_id: result[i].event_id,
            title: result[i].title,
            start: result[i].start,
            end: result[i].end,
            color: result[i].color,
            url: result[i].url
        }); 	
    })
	var calendar = $('#calendar').fullCalendar({
	    defaultView: 'month',
		 timeZone: 'local',
	    editable: true,
        selectable: true,
		selectHelper: true,
        select: function(start, end) {
				//alert(start);
				//alert(end);
				$('#event_start_date').val(moment(start).format('YYYY-MM-DD'));
				$('#event_end_date').val(moment(end).format('YYYY-MM-DD'));
				$('#event_entry_modal').modal('show');
			},
        events: events,
	    eventRender: function(event, element, view) { 
    element.append('<span class="close-event" style="float:right; margin-right:5px; cursor:pointer;">×</span>');
    element.find('.close-event').click(function() {
        delete_event(event.event_id);
    });
    
    // Optional: Also make the entire event clickable to delete if preferred
    element.click(function() {
        if(confirm('Delete this event?')) {
            delete_event(event.event_id);
        }
    });
}
		}); //end fullCalendar block	
	  },//end success block
	  error: function (xhr, status) {
	  alert(response.msg);
	  }
	});//end ajax block	
}

function save_event()
{
var event_name=$("#event_name").val();
var event_start_date=$("#event_start_date").val();
var event_end_date=$("#event_end_date").val();
if(event_name=="" || event_start_date=="" || event_end_date=="")
{
alert("Please enter all required details.");
return false;
}
$.ajax({
 url:"save_event.php",
 type:"POST",
 dataType: 'json',
 data: {event_name:event_name,event_start_date:event_start_date,event_end_date:event_end_date},
 success:function(response){
   $('#event_entry_modal').modal('hide');  
   if(response.status == true)
   {
	alert(response.msg);
	location.reload();
   }
   else
   {
	 alert(response.msg);
   }
  },
  error: function (xhr, status) {
  console.log('ajax error = ' + xhr.statusText);
  alert(response.msg);
  }
});    
return false;
} function delete_event(event_id) {
     {
        $.ajax({
            url: 'delete_event.php',
            type: 'POST',
            dataType: 'json',
            data: {event_id: event_id},
            success: function(response) {
                if(response.status == true) {
                    alert(response.msg);
                    // Remove event from calendar without full reload
                    $('#calendar').fullCalendar('removeEvents', event_id);
                    // Or reload the page if needed
                    location.reload();
                } else {
                    alert(response.msg);
                }
            },
            error: function(xhr, status) {
                console.log('ajax error = ' + xhr.statusText);
                alert("Error communicating with server");
            }
        });
    }
}
</script> <style>
/* FullCalendar Size Fixes */
#calendar {
    width: 100%;
    min-height: 800px; /* Adjust this value as needed */
    margin: 20px auto;
}

/* Calendar Container */
.fc {
    font-size: 1em; /* Base font size for calendar */
}

/* Header buttons */
.fc-button {
    padding: 0.6em 1em !important;
    font-size: 1em !important;
}

/* Day cells */
.fc-dayGridMonth-view .fc-day-grid-container {
    height: auto !important;
    min-height: 600px !important;
}

/* Event items */
.fc-event {
    font-size: 1em !important;
    padding: 0.3em 0.5em !important;
}

/* Date numbers */
.fc-day-number {
    font-size: 1.2em;
    padding: 0.5em !important;
}

/* Header toolbar */
.fc-header-toolbar {
    padding: 1em 0;
    margin-bottom: 1em !important;
}

/* Day headers */
.fc-col-header-cell {
    padding: 0.5em 0 !important;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    #calendar {
        min-height: 600px;
    }
    .fc-header-toolbar h2 {
        font-size: 1.2em;
    }
}

/* Your existing overrides */
.fc-header-toolbar {
    background: linear-gradient(to right, #a87bdc, #6a5acd);
    color: white;
    border-radius: 12px;
}

.fc-button {
    background: white !important;
    color: #6a5acd !important;
    border: 2px solid #6a5acd !important;
    border-radius: 25px !important;
}

.fc-button:hover {
    background: #6a5acd !important;
    color: white !important;
}

.fc-daygrid-day.fc-day-today {
    background-color: #f0e6ff !important;
    border: 2px solid #a87bdc !important;
}

.fc-event {
    background: linear-gradient(to right, #a87bdc, #6a5acd) !important;
    border: none !important;
}
/*  Navigation Bar  */
nav {
    background: linear-gradient(to right, #a87bdc, #6a5acd); /* Purple gradient */
    padding: 15px;
    border-radius: 15px;
    margin: 20px auto;
    width: 90%; 
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}


nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: inline; 
    justify-content: space-around; 
    align-items: center;
}
nav ul li{
    display:inline;
}
/* Style the navigation links */
nav ul li a {
    display: inline-block;
    padding: 10px 20px; 
    background-color: white;
    color: #6a5acd;
    font-size: 16px;
    font-weight: bold;
    border-radius: 25px;
    transition: 0.3s;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    border: 2px solid #6a5acd;
    text-decoration: none; 
}

/* Hover effect */
nav ul li a:hover {
    background-color: #6a5acd;
    color: white;
}
  footer {
    background: var(--dark);
    color: white;
    padding: 2rem;
    margin-top: 3rem;
    text-align: center;
    font-family: 'Indie Flower', cursive;
    font-size: 1.2rem;
    position: relative;
  }
</style> <footer>
    <p>2025 Gamified To-Do List </p>
  </footer>

</html> 