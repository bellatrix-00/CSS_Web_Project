
// Function to update progress
function updateProgress() {
    const totalTasks = parseInt(document.getElementById('totalTasks').value);
    const completedTasks = parseInt(document.getElementById('completedTasks').value);

     // Ensure completedTasks is never greater than totalTasks
     if (completedTasks > totalTasks) {
        completedTasks = totalTasks; 
        alert("Completed tasks cannot exceed total tasks. Adjusting to total tasks.");
    }
    // Calculate progress
    const progress = (completedTasks / totalTasks) * 100;
    document.getElementById('progressBar').style.width = progress + '%';
    document.getElementById('progressBar').textContent = Math.round(progress) + '%';

    // Show a success message based on the progress
if (progress === 100) {
    alert("Congratulations! You made it!!");
} else if (progress >= 70) {
    alert("Congratulations! You're almost there!!");
}


}



  // Function to submit bug report
function submitBugReport() {
    const bugReport = document.getElementById("bug-report").value;
    if (bugReport) {
        alert("Thank you for your feedback!");
        document.getElementById("bug-report").value = "";
    }
}



// Form validation for feedback
document.getElementById("feedback-form").addEventListener("submit", function (event) {
    event.preventDefault();
    const rating = document.getElementById("feedback-rating").value;
    const suggestions = document.getElementById("feedback-suggestions").value;

    if (rating && suggestions) {
        alert("Thank you for your feedback!");
        this.reset();
    } else {
        alert("Please fill out all fields.");
    }
});
function saveTask() {
    const taskText = $("#task-input").val().trim();
    const taskDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDate).padStart(2, '0')}`;

    if (taskText) {
        $.post("save_task.php", {
            task_date: taskDate,
            task_text: taskText,
            color: selectedColor
        }, function(response) {
            if (response.success) {
                // 1. Update local tasks object
                if (!tasks[taskDate]) tasks[taskDate] = [];
                tasks[taskDate].push({
                    id: response.task_id, // Important for future updates
                    text: taskText,
                    color: selectedColor,
                    completed: false
                });

                // 2. Refresh calendar
                updateDayTasks(selectedDate); // Updates just this day
                closeModal();
            }
        }, 'json');
    }
} function deleteTask(taskId, dateKey, index) {
    $.post("delete_task.php", { task_id: taskId }, function(response) {
        if (response.success) {
            // 1. Update local tasks
            tasks[dateKey].splice(index, 1);
            
            // 2. Refresh calendar
            updateDayTasks(dateKey.split('-')[2]); // Extract day number
        }
    }, 'json');
}function fetchAndRenderTasks() {
    const month = currentDate.getMonth() + 1;
    const year = currentDate.getFullYear();

    $.get("fetch_tasks.php", { month, year }, function(data) {
        tasks = {}; // Reset tasks
        data.forEach(task => {
            const dateKey = task.task_date.split(' ')[0];
            if (!tasks[dateKey]) tasks[dateKey] = [];
            tasks[dateKey].push(task);
        });
        createCalendar(); // Full re-render
    }, 'json');
}