<?php
require_once "connect.php";
echo "Connected to DB successfully!";
?>
